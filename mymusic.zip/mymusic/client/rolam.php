<div style="font-size: 20px">
    2022 őszén kezdtem el először foglalkozni a rappel, amikor megtudtam, hogy az egyik ismerősöm zenei alapokat készít hobbi szinten.
    Már korábban is gondolkoztam rajta, hogy megpróbáltatom magam e területen, mivel már előtte is volt rá példa, hogy szövegeket, verseket írtam, saját magam és barátaim szórakoztatására.
    Akkor még nem voltam elég elszánt hozzá, illetve nem is láttam át, hogy mi szerint épül fel egy komplett zene.
    De az ismerősömnek és egyben jóbarátomnak köszönhetően, beleláttam a zene világába, ami már az elejétől fogva magával ragadott.
    Azóta én is megtanultam zenei alapot készíteni, bár leginkább a szövegírás és az előadás vonz engem.
    Számomra ez az egész egyfajta terápia, ami segít a belső gondolataimat, érzéseimet kifejteni.
    Első zenémet 2023 márciusában adtam ki, "Melyikünk röhög" címmel, amit az egykori barátunk és a köztünk lévő elfajult vita ihlette meg.
    Törekedve a lehető legjobb minőségre, a véglegesítésnél a hangfelvételeket egy arra kialakított stúdióban rögzítettük, akárcsak a későbbi munkáink során.
    A "Melyikünk röhög" szókimondó sértő szövege nem tartalmaz semmilyen ferdítést, viszont a kívülálló emberek nehezen azonosulhatnak a szöveg mondanivalójával.
    Ez, a hirtelen felindulásomnak és az összeszedetlenségemnek köszönhető, ennek ellenére a legtöbben mégis pozitívan fogadták első alkotásomat.
    Az emberek visszajelzései még inkább biztattak arra, hogy folytassam a zenék kiadását, jelenleg 8 kiadott zenével rendelkezem.
    Mivel a rappelést csak hobbi szinten űzöm, a körülöttem lévő hétköznapi akadályok mellett, ezért sajnos kevés időt tudok fordítani rá.
    De természetesen a terveim között van a zenék jövőbeni gyarapítása, a szabadidőmtől függően.
</div>