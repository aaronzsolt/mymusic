<div class="m-3">
<div>
    <h2>YouTube:</h2>
    <a href="https://www.youtube.com/@zlotymusic0520" target="_blank"><h5>https://www.youtube.com/@zlotymusic0520</h5></a>
</div>
<br>
<div>
    <h2>Spotify:</h2>
    <a href="https://open.spotify.com/artist/2SNNlfJUFJazH2zzT5K56l" target="_blank"><h5>https://open.spotify.com/artist/2SNNlfJUFJazH2zzT5K56l</h5></a>
</div>
<br>
<div>
    <h2>Apple Music:</h2>
    <a href="https://music.apple.com/hu/artist/z%C5%82oty/1676988260" target="_blank"><h5>https://music.apple.com/hu/artist/z%C5%82oty/1676988260</h5></a>
</div>
<br>
<div>
    <h2>Instagram:</h2>
    <a href="https://www.instagram.com/aaronzsolt/" target="_blank"><h5>https://www.instagram.com/aaronzsolt/</h5></a>
</div>
<br>
<div>
    <h2>TikTok:</h2>
    <a href="https://www.tiktok.com/@zlotymusic" target="_blank"><h5>https://www.tiktok.com/@zlotymusic</h5></a>
</div>
<br>
<div>
    <h2>E-mail:</h2>
    <h5 id="email">aaronzsolt@gmail.com</h5>
</div>
</div>