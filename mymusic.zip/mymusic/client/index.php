<?php
//az url lekérése
$currentURL =
$_SERVER["REQUEST_URI"];
//megkeresi az index.php pozicióját a linkben
$indexPosition = strpos($currentURL, 'index.php');
//substringgel levágja a fölösleges részt
$pathAfterIndex = substr($currentURL, $indexPosition );
//átrakja egy végleges változóba
$currentPage = $pathAfterIndex;
echo "<script>console.log('" . $currentPage . "');</script>";
?>

<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
  <script src="getData.js"></script>
  <title>Złoty</title>
  <style>
    .active{
      color: white;
    }
    a{
      text-decoration: none;
      color: black;
    }
    a:hover{
      text-decoration: none;
      color:white;
    }
  </style>
  
</head>

<body>
  <div class="bg-dark text-light p-0">

    <nav class="navbar navbar-expand-lg navbar-light bg-warning">
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav"> 
          
          <li class="nav-item p-2 m-0">
            <a <?php 
            if($currentPage == 'index.php')
            echo 'class="active"'; ?>
             href="index.php"><h1>Kiadott zenék</h1></a>
          </li>
          <li class="nav-item p-2 m-0">
            <a <?php 
            if($currentPage == 'index.php?prog=rolam.php')
            echo 'class="active"'; ?> href="index.php?prog=rolam.php"><h1>Rólam</h1></a>
          </li>
          <li class="nav-item p-2 m-0">
          <a <?php 
            if($currentPage == 'index.php?prog=elerhetosegek.php')
            echo 'class="active"'; ?> href="index.php?prog=elerhetosegek.php"><h1>Elérhetőségek</h1></a>
          </li>
        </ul>
      </div>
    </nav>

    <div class="row p-2 m-0 justify-content-center">
      <!--az URL-ben kapott program betöltése-->
      <?php
        if(isset($_GET['prog']))
          include $_GET['prog'];
        else
          include 'fooldal.php';
      ?>  
    </div>

  </div>

<script src="bootstrap/jquery-3.5.1.min.js"></script>
<script src="bootstrap/bootstrap.bundle.js"></script>
</body>
</html>