<?php
//az url lekérése
$currentURL =
$_SERVER["REQUEST_URI"];
//megkeresi az index.php pozicióját a linkben
$indexPosition = strpos($currentURL, 'index.php');
//substringgel levágja a fölösleges részt
$pathAfterIndex = substr($currentURL, $indexPosition );
//átrakja egy végleges változóba
$currentPage = $pathAfterIndex;
echo "<script>console.log('" . $currentPage . "');</script>";
?>

<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
  <script src="getData.js"></script>
  <title>Złoty</title>
  <style>
    .active{
      color: white;
    }

    a{
      text-decoration: none;
      color: black;
    }

    a:hover{
      text-decoration: none;
      color: white;
    }

    #imageBB{
      display: flex;
      justify-content: center;
    }

    .navbar{
      background-color: orange;
    }

    #kep{
      transition: transform 0.3s ease; 
    }

    #kep:hover{
      transform: scale(1.05);
      box-shadow: 0px 0px 25px 0px orange;
    }

    .kartya {
      width: fit-content;
      align-self: center;
    }

    .kartya + h2{
      color: white;
    }

    .kartya:hover + h2{
      color: orange;
    }

    #video:hover{
      box-shadow: 0px 0px 25px 0px orange;
    }
  </style>
</head>

<body>
  <div class="bg-dark text-light p-0">

    <nav class="navbar navbar-expand-lg navbar-light">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav"> 
        <li class="nav-item p-0 m-3">
            <a <?php 
            if($currentPage == 'index.php')
            echo 'class="active"'; ?> href="index.php"><h1>Rólam</h1></a>
          </li>
          <li class="nav-item p-0 m-3">
            <a <?php 
            if($currentPage == 'index.php?prog=kiadott.php')
            echo 'class="active"'; ?>
             href="index.php?prog=kiadott.php"><h1>Kiadott zenék</h1></a>
          </li>
          <li class="nav-item p-0 m-3">
            <a <?php 
            if($currentPage == 'index.php?prog=leiras.php')
            echo 'class="active"'; ?>
             href="index.php?prog=leiras.php"><h1>Leírás</h1></a>
          </li>
          <li class="nav-item p-0 m-3">
          <a <?php 
            if($currentPage == 'index.php?prog=elerhetosegek.php')
            echo 'class="active"'; ?> href="index.php?prog=elerhetosegek.php"><h1>Elérhetőségek</h1></a>
          </li>
        </ul>
      </div>
    </nav>

    <div class="p-3 m-0">
      <!--az URL-ben kapott program betöltése-->
      <?php
        if(isset($_GET['prog']))
          include $_GET['prog'];
        else
          include 'rolam.php';
      ?>  
    </div>

  </div>

<script src="bootstrap/jquery-3.5.1.min.js"></script>
<script src="bootstrap/bootstrap.bundle.js"></script>
</body>
</html>