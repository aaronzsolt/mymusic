<div class="text-center">

<div id="youtubePlayer"></div>  
<script>
  getData("../server/leiras.php", renderMusic) 
  function renderMusic(data){
    console.log(data);
    for(let obj of data){
      console.log(obj.link, obj.cim);
      document.getElementById('youtubePlayer').innerHTML += `
      <a name="${obj.id}"></a>
      <div class="d-flex flex-column justify-content-center p-0 m-3">
        <div id="${obj.id}" class="p-0 m-3 kartya"><iframe width="560" height="315" src="https://www.youtube.com/embed/${obj.link}" frameborder="0" allowfullscreen id="video" class="link"></iframe></div>
        <h2>${obj.cim}</h2>
      </div>
      `
    }
    scrollFunction()
  }

  function scrollFunction() {
      // Ellenőrizd, hogy van-e targetElementID az URL-ben
      if (window.location.hash) {
        // Ha van, akkor eltávolítjuk a '#' karaktert
        var targetElementID = window.location.hash.substring(1);
        console.log((targetElementID));
        // Ellenőrizzük, hogy létezik-e az elem az oldalon
        if (document.getElementById(targetElementID)) {
          // Ha igen, akkor görgetünk az elemhez
          document.getElementById(targetElementID).scrollIntoView();
        }
      }
    }
</script>
</div>
