<div class="text-center">

<div id="youtubePlayer"></div>  
<script>
  getData("../server/leiras.php", renderMusic) 
  function renderMusic(data){
    console.log(data);
    for(let obj of data){
      console.log(obj.link, obj.cim);
      document.getElementById('youtubePlayer').innerHTML += `
      <div class="d-flex flex-column justify-content-center p-0 m-5">
        <div id="${obj.id}" class="p-0 m-2 kartya"><iframe width="560" height="315" src="https://www.youtube.com/embed/${obj.link}" frameborder="0" allowfullscreen id="video" class="link"></iframe></div>
        <h2>${obj.cim}</h2>
      </div>
      `
    }
  }

  // Eseménykezelő hozzáadása minden kártya osztályú elemhez
  document.addEventListener('click', function(event) {
    // Ellenőrizzük, hogy a kattintás az obj.borito elemre történt-e
    if (event.target.classList.contains('borito')) {
      // Azonosítók kinyerése
      let clickedId = event.target.parentElement.id;
      let linkId = event.target.dataset.linkId;
      
      // Ellenőrizzük, hogy az azonosítók egyeznek-e
      if (clickedId === linkId) {
        // Ha egyeznek, akkor navigáljunk a linkhez
        window.location.href = event.target.dataset.link;
      }
    } else if (event.target.classList.contains('link')) {
      // Ne tegyünk semmit, ha az obj.link-re kattintanak
      event.preventDefault();
    }
  });
</script>
</div>