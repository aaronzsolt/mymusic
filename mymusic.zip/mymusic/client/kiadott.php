<div class="text-center m-3">
<h3>A zene lejátszásához és további leírásához kattints a kívánt zene borítójára!</h5>

<div class="row" id="ImageBB"></div>

<script>
  getData("../server/kiadott.php", renderBorito)
  function renderBorito(data) {
    console.log(data);
    for(let obj of data){
      console.log(obj.borito, obj.cim);
      document.getElementById('ImageBB').innerHTML += `
      <div class="p-0 m-3">
        <div id="${obj.id}" class="p-0 m-3 kartya">
          <a href="index.php?prog=leiras.php&targetElementID=#${obj.id}" class="linkwrap">
            <div class="blocker"></div>
            <iframe width="300" height="300" src="https://i.ibb.co/${obj.borito}" frameborder="0" allowfullscreen class="borito"></iframe>
          </a>      
        </div> 
        <h2>${obj.cim}</h2>  
      </div>
      `
    }
  } 
</script>
</div>