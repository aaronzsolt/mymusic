<div class="text-center">

<div class="row" id="ImageBB"></div>
<script>
  getData("../server/kiadott.php", renderBorito)
  function renderBorito(data) {
    console.log(data);
    for(let obj of data){
      console.log(obj.borito, obj.cim);
      document.getElementById('ImageBB').innerHTML += `
      <div class="p-0 m-3">
        <div id="${obj.id}" class="p-0 m-3 kartya">
          <iframe width="300" height="300" src="https://i.ibb.co/${obj.borito}" frameborder="0" allowfullscreen id="kep" class="borito"></iframe>
        </div>
        <h2>${obj.cim}</h2>
      </div>
      `
    }
  }

  // Eseménykezelő hozzáadása minden kártya osztályú elemhez
  document.addEventListener('click', function(event) {
    // Ellenőrizzük, hogy a kattintás az obj.borito elemre történt-e
    if (event.target.classList.contains('borito')) {
      // Azonosítók kinyerése
      let clickedId = event.target.parentElement.id;
      let linkId = event.target.dataset.linkId;
      
      // Ellenőrizzük, hogy az azonosítók egyeznek-e
      if (clickedId === linkId) {
        // Ha egyeznek, akkor navigáljunk a linkhez
        window.location.href = event.target.dataset.link;
      }
    } else if (event.target.classList.contains('link')) {
      // Ne tegyünk semmit, ha az obj.link-re kattintanak
      event.preventDefault();
    }
  });
</script>

<br>
<h5>A zene lejátszásához és további leírásához kattintson a zene borítójára!</h5>
</div>