<div class="text-center">
<!--
<div id="youtubePlayer"></div>  
<script>
  getData("../server/kiadott.php", renderMusic) 
  function renderMusic(data){
    console.log(data);
    for(let obj of data){
        console.log(obj.link);
        document.getElementById('youtubePlayer').innerHTML += `<div>${embedYouTubeVideo(obj.link)}</div>`
        
    }
  } 
  function embedYouTubeVideo(videoId) {
    return '<iframe width="560" height="315" src="https://www.youtube.com/embed/' + videoId + '" frameborder="0" allowfullscreen></iframe>';
  }   
</script>
-->
<div class="row" id="ImageBB"></div>

<script>
  getData("../server/kiadott.php", renderBorito)
  function renderBorito(data) {
    console.log(data);
    for(let obj of data){
      console.log(obj.borito, obj.cim);
      document.getElementById('ImageBB').innerHTML += `
      <div class="p-0 m-3" onmouseover="changeColorAndBorder(this)" onmouseout="changeBackAndRemoveBorder(this)">
        <div class="p-0 m-3">${imgbb(obj.borito)}</div>
        <h2>${obj.cim}</h2>
      </div>
      `
    }
  }
  function imgbb(boritoId) {
    return '<iframe width="300" height="300" src="https://i.ibb.co/' + boritoId + '" frameborder="0" allowfullscreen id="track"></iframe>';
  }
  
  function changeColorAndBorder(element) {
    var h2 = element.querySelector('h2');
    h2.style.color = 'orange';
    var track = element.querySelector('#track');
    track.style.border = '3px solid orange';
  }
  function changeBackAndRemoveBorder(element) {
    var h2 = element.querySelector('h2');
    h2.style.color = 'white';
    var track = element.querySelector('#track');
    track.style.border = 'none'; 
  }
</script>

<br>
<h5>A zene lejátszásához és további leírásához kattintson a zene borítójára!</h5>
</div>
