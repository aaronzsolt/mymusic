<div class="text-center">

<div class="row" id="ImageBB"></div>
<script>
  getData("../server/kiadott.php", renderBorito)
  function renderBorito(data) {
    console.log(data);
    for(let obj of data){
      console.log(obj.borito, obj.cim);
      document.getElementById('ImageBB').innerHTML += `
      <div class="p-0 m-3">
        <div id="${obj.id}" class="p-0 m-3 kartya">${imgbb(obj.borito)}</div>
        <h2>${obj.cim}</h2>
      </div>
      `
    }
  }
  function imgbb(boritoId) {
    return '<iframe width="300" height="300" src="https://i.ibb.co/' + boritoId + '" frameborder="0" allowfullscreen id="kep"></iframe>';
  }
</script>

<br>
<h5>A zene lejátszásához és további leírásához kattintson a zene borítójára!</h5>
</div>
