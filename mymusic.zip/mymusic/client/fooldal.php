<h1 class="w-100 text-center">Főoldal</h1>
<div id="youtubePlayer"></div>
<script>
  getData("../server/fooldal.php", renderMusic) 
  function renderMusic(data){
    console.log(data);
    for(let obj of data){
        console.log(obj.link);
        document.getElementById('youtubePlayer').innerHTML += `<div>${embedYouTubeVideo(obj.link)}</div>`
        
    }
  } 
  function embedYouTubeVideo(videoId) {
    return '<iframe width="560" height="315" src="https://www.youtube.com/embed/' + videoId + '" frameborder="0" allowfullscreen></iframe>';
  }   
</script>

<div id="ImageBB"></div>
<script>
  getData("../server/fooldal.php", renderBorito)
  function renderBorito(data) {
    console.log(data);
    for(let obj of data){
      console.log(obj.borito);
      document.getElementById('ImageBB').innerHTML += `<div>${imgbb(obj.borito)}</div>`
    }
  }
  function imgbb(boritoId) {
    return '<iframe width="640" height="640" src="https://i.ibb.co/' + boritoId + '" frameborder="0" allowfullscreen></iframe>';
  }
</script>

<!--<a href="https://ibb.co/GQXQQY1"><img src="https://i.ibb.co/zV1VV9L/cover-melyik-nk-r-h-g.jpg" alt="cover-melyik-nk-r-h-g"/></a>-->
<!--<a href="https://ibb.co/tCjvGqG"><img src="https://i.ibb.co/mzZ2j9j/cover-hossz-az-t.jpg" alt="cover-hossz-az-t"/></a>-->
<!--<a href="https://ibb.co/CHNmvMs"><img src="https://i.ibb.co/nLZ6fn8/cover-keresem.jpg" alt="cover-keresem" border="0" /></a>-->
<!--<a href="https://ibb.co/jG4xpgB"><img src="https://i.ibb.co/q914ZkX/cover-ez-vagyok.jpg" alt="cover-ez-vagyok" border="0" /></a>-->