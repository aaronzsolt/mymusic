<div class="text-center">

<!--
<div id="youtubePlayer"></div>  
<script>
  getData("../server/fooldal.php", renderMusic) 
  function renderMusic(data){
    console.log(data);
    for(let obj of data){
        console.log(obj.link);
        document.getElementById('youtubePlayer').innerHTML += `<div>${embedYouTubeVideo(obj.link)}</div>`
        
    }
  } 
  function embedYouTubeVideo(videoId) {
    return '<iframe width="560" height="315" src="https://www.youtube.com/embed/' + videoId + '" frameborder="0" allowfullscreen></iframe>';
  }   
</script>
-->

<div id="ImageBB"></div>
<script>
  getData("../server/fooldal.php", renderBorito)
  function renderBorito(data) {
    console.log(data);
    for(let obj of data){
      console.log(obj.borito, obj.cim);
      document.getElementById('ImageBB').innerHTML += `<div>${imgbb(obj.borito)}</div>`
      document.getElementById('ImageBB').innerHTML += `<h3>${obj.cim}</h3>`
    }
  }
  function imgbb(boritoId) {
    return '<iframe width="300" height="300" src="https://i.ibb.co/' + boritoId + '" frameborder="0" allowfullscreen></iframe>';
  }
</script>
</div>